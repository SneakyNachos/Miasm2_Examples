Crack noprelo - The goal is to show the Good Boy message.
